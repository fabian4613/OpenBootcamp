rango = range(1,21)

# Se muestra el rango de números desde 20 hasta 1
for i in reversed(rango):
    print(f"- {i}")