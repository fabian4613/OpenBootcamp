rango = range(1,101)

# Se muestra el rango de números desde 100 hasta 1
for i in reversed(rango):
    print(f"- {i}")