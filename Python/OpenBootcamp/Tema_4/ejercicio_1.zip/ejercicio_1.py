edad = int(input("Hola, cual es tu edad?"))

if edad > 17:
    
    print("Eres mayor de edad")

else:

    print("Eres menor de edad")

